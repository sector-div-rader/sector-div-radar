# build_site.py - 生成 index.html Dashboard V20.2
# ============================================
# V20.2 改動：
#   1. 回測區合併「底背離 + 頂背離」一個表
#   2. 回測區欄位可排序
# ============================================

import os
import pandas as pd
from datetime import datetime, timezone, timedelta
import json

def build_html():
    now_hkt = datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d %H:%M')
    today = datetime.now(timezone(timedelta(hours=8))).strftime('%Y-%m-%d')
    yesterday = (datetime.now(timezone(timedelta(hours=8))) - timedelta(days=1)).strftime('%Y-%m-%d')

    if not os.path.exists('history.csv'):
        df = pd.DataFrame()
    else:
        try:
            df = pd.read_csv('history.csv', encoding='utf-8-sig')
        except Exception as e:
            print(f"⚠️ 讀 history.csv 失敗: {e}")
            df = pd.DataFrame()

    if not df.empty and '日期' in df.columns:
        df['日期_str'] = df['日期'].astype(str).str[:10]
        today_df = df[df['日期_str'] == today]
        yesterday_df = df[df['日期_str'] == yesterday]
        df['日期_dt'] = pd.to_datetime(df['日期'], errors='coerce')
        cutoff = datetime.now() - timedelta(days=30)
        recent = df[df['日期_dt'] >= cutoff]
    else:
        today_df = pd.DataFrame()
        yesterday_df = pd.DataFrame()
        recent = pd.DataFrame()

    dashboard_data = {}
    if os.path.exists('dashboard_data.json'):
        try:
            with open('dashboard_data.json', 'r', encoding='utf-8') as f:
                dashboard_data = json.load(f)
        except Exception as e:
            print(f"⚠️ 讀 dashboard_data.json 失敗: {e}")

    backtest_data = {}
    if os.path.exists('backtest_results.json'):
        try:
            with open('backtest_results.json', 'r', encoding='utf-8') as f:
                backtest_data = json.load(f)
        except Exception as e:
            print(f"⚠️ 讀 backtest_results.json 失敗: {e}")

    nq_data = dashboard_data.get('nq_key_levels', {'high': 0, 'low': 0, 'current': 0})
    nq_ema = dashboard_data.get('nq_ema') or {}
    fmp_calendar = dashboard_data.get('fmp_calendar', '')

    total_signals = len(df) if not df.empty else 0
    today_count = len(today_df)
    yesterday_count = len(yesterday_df)
    today_top = len(today_df[today_df['方向'] == '頂']) if not today_df.empty else 0
    today_bot = len(today_df[today_df['方向'] == '底']) if not today_df.empty else 0
    today_strong = len(today_df[today_df['強度'] == '強']) if not today_df.empty else 0

    diff_total = today_count - yesterday_count
    if yesterday_count == 0:
        diff_str = '首次'
        diff_class = ''
    else:
        diff_str = f'{diff_total:+d}'
        diff_class = 'up' if diff_total > 0 else 'down' if diff_total < 0 else ''

    strength_counts = {'強': 0, '中': 0, '弱': 0}
    if not today_df.empty and '強度' in today_df.columns:
        for s in strength_counts:
            strength_counts[s] = int((today_df['強度'] == s).sum())

    trend_dates, trend_top, trend_bot = [], [], []
    if not recent.empty and '日期_dt' in recent.columns:
        grouped = recent.groupby(recent['日期_dt'].dt.strftime('%Y-%m-%d'))
        for date, group in grouped:
            trend_dates.append(date)
            trend_top.append(int((group['方向'] == '頂').sum()))
            trend_bot.append(int((group['方向'] == '底').sum()))
        combined = sorted(zip(trend_dates, trend_top, trend_bot))
        trend_dates = [c[0] for c in combined]
        trend_top = [c[1] for c in combined]
        trend_bot = [c[2] for c in combined]

    top_tickers = []
    if not recent.empty and '標的' in recent.columns:
        counts = recent['標的'].value_counts().head(5)
        max_count = counts.max() if len(counts) > 0 else 1
        for t, c in counts.items():
            top_tickers.append({'ticker': t, 'count': int(c), 'pct': int(c / max_count * 100)})

    resonance = {}
    if not recent.empty:
        for _, row in recent.iterrows():
            if pd.isna(row.get('日期_dt')):
                continue
            key = (row['標的'], row['方向'])
            resonance.setdefault(key, set()).add(row['週期'])

    resonance_list = []
    for (ticker, dir_), levels in resonance.items():
        if len(levels) >= 2:
            name = ''
            if '中文名' in recent.columns:
                m = recent[recent['標的'] == ticker]
                if not m.empty:
                    name = m.iloc[0]['中文名']
            lvl_str = '+'.join(sorted(levels, key=lambda x: {'M': 1, 'W': 2, 'D': 3, '4H': 4}.get(x, 99)))
            stars = '⭐' * len(levels)
            resonance_list.append({'ticker': ticker, 'name': name, 'dir': dir_, 'levels': lvl_str, 'count': len(levels), 'stars': stars})
    resonance_list = sorted(resonance_list, key=lambda x: -x['count'])

    DISPLAY_COLS = ['日期_str', '標的', '中文名', '週期', '方向',
                    '前高/低', '現價', '價變化%', 'DIF變化%', 'J變化%',
                    'DIF有冇', 'J有冇', '強度', 'lookback', 'tag', '共振', '歷史勝率']

    HEADER_LABELS = {
        '日期_str': '日期', '標的': '標的', '中文名': '中文名',
        '週期': '週期', '方向': '方向', '前高/低': '前高/低',
        '現價': '現價', '價變化%': '價變化%',
        'DIF變化%': 'DIF變化%', 'J變化%': 'J變化%',
        'DIF有冇': 'DIF', 'J有冇': 'J',
        '強度': '強度', 'lookback': '長/短', 'tag': '型態', '共振': '共振',
        '歷史勝率': '歷史勝率'
    }

    STRENGTH_PCT = {'強': 90, '中': 60, '弱': 30}

    def df_to_rows(d):
        if d.empty:
            return f"<tr><td colspan='{len(DISPLAY_COLS)}' style='text-align:center;color:#888;padding:20px;'>暫無數據</td></tr>"

        d = d[[c for c in DISPLAY_COLS if c in d.columns]]
        rows = []
        for _, row in d.iterrows():
            direction = row.get('方向', '')
            strength = row.get('強度', '')
            pct = STRENGTH_PCT.get(strength, 30)
            resonance_val = row.get('共振', '單指標')

            if direction == '頂':
                row_class = 'top-row'
                dir_html = '🔴 頂 ▼'
            elif direction == '底':
                row_class = 'bot-row'
                dir_html = '🟢 底 ▲'
            else:
                row_class = ''
                dir_html = direction

            cells = []
            for col in d.columns:
                val = row[col]
                if col == '方向':
                    val = dir_html
                elif col == '強度':
                    val = f'<div class="strength-bar"><div class="strength-fill strength-{val}" style="width:{pct}%;"></div><span class="strength-text">{val}</span></div>'
                elif col == 'lookback':
                    val = '長' if val == 'long' else '短'
                elif col == 'DIF有冇':
                    val = '✅' if val == '有' else '—'
                elif col == 'J有冇':
                    val = '✅' if val == '有' else '—'
                elif col == '共振':
                    if val == '雙指標':
                        val = '<span class="resonance-badge resonance-dual">⭐⭐ 雙指標</span>'
                    else:
                        val = '<span class="resonance-badge resonance-single">單指標</span>'
                elif col == '歷史勝率':
                    if val and str(val) != 'nan' and str(val) != '':
                        wr = float(str(val).replace('%', ''))
                        if wr >= 65:
                            val = f'<span style="color:#3fb950;font-weight:bold;">{val} ⭐⭐⭐</span>'
                        elif wr >= 55:
                            val = f'<span style="color:#d29922;font-weight:bold;">{val} ⭐⭐</span>'
                        else:
                            val = f'<span style="color:#f85149;">{val} ⭐</span>'
                    else:
                        val = '—'
                elif col in ['DIF變化%', 'J變化%']:
                    if pd.isna(val) or val == '':
                        val = '—'
                    else:
                        val = f'{val}%'
                cells.append(f"<td>{val}</td>")

            row_json = {
                'ticker': str(row.get('標的', '')),
                'name': str(row.get('中文名', '')),
                'date': str(row.get('日期_str', '')),
                'level': str(row.get('週期', '')),
                'direction': str(direction),
                'prev_price': str(row.get('前高/低', '')),
                'current_price': str(row.get('現價', '')),
                'price_change': str(row.get('價變化%', '')),
                'dif_change': str(row.get('DIF變化%', '')),
                'j_change': str(row.get('J變化%', '')),
                'has_dif': str(row.get('DIF有冇', '')),
                'has_j': str(row.get('J有冇', '')),
                'strength': str(strength),
                'lookback': '長' if str(row.get('lookback', '')) == 'long' else '短',
                'tag': str(row.get('tag', '')),
                'resonance': str(resonance_val),
                'win_rate': str(row.get('歷史勝率', '')),
            }
            row_json_str = json.dumps(row_json, ensure_ascii=False).replace("'", "&#39;")

            rows.append(f'<tr class="{row_class}" data-direction="{direction}" data-strength="{strength}" data-resonance="{resonance_val}" data-ticker="{row.get("標的","")}" data-json=\'{row_json_str}\' onclick="showDetail(this)">')
            rows.append("".join(cells))
            rows.append("</tr>")
        return "".join(rows)

    header_html = "".join(f"<th>{HEADER_LABELS.get(c, c)}</th>" for c in DISPLAY_COLS)

    resonance_html = ""
    if resonance_list:
        for r in resonance_list[:10]:
            resonance_html += f'<div class="resonance-item">{r["stars"]} {r["name"]} ({r["ticker"]}) | {r["levels"]} {r["dir"]}背離</div>'
    else:
        resonance_html = '<p style="color:var(--muted);">暫無共振訊號</p>'

    top_tickers_html = ""
    for t in top_tickers:
        top_tickers_html += f'''
        <div class="bar-row">
          <span class="bar-label">{t['ticker']}</span>
          <div class="bar-track"><div class="bar-fill" style="width:{t['pct']}%;"></div></div>
          <span class="bar-count">{t['count']}</span>
        </div>'''

    fmp_html = fmp_calendar.replace('\n', '<br>') if fmp_calendar else '<p style="color:var(--muted);">暫無數據</p>'

    if nq_ema and nq_ema.get('current'):
        band_top = nq_ema.get('band_top', 0)
        band_bot = nq_ema.get('band_bot', 0)
        e3500 = nq_ema.get('ema3500')
        current = nq_ema['current']
        w_pts = band_top - band_bot
        w_pct = (w_pts / current) * 100 if current else 0

        if w_pct < 0.15:
            band_status = f'🚨 極度黏合 ({w_pts:.1f} 點 / {w_pct:.2f}%)'
        elif w_pct > 0.60:
            band_status = f'⚠️ 寬幅發散 ({w_pts:.1f} 點 / {w_pct:.2f}%)'
        else:
            band_status = f'🟢 常態帶寬 ({w_pts:.1f} 點 / {w_pct:.2f}%)'

        ema_html = f'''
        <div style="line-height:1.8;">
          <div>📍 現價：<strong>{current:,.1f}</strong></div>
          <div>📊 5m EMA 700-1000 帶：<strong>{band_bot:,.1f} - {band_top:,.1f}</strong></div>
          <div>└─ {band_status}</div>
          <div>🏛️ 5m EMA 3500：<strong>{f"{e3500:,.1f}" if e3500 else "數據不足"}</strong></div>
        </div>'''
    else:
        ema_html = '<p style="color:var(--muted);">暫無數據</p>'

    trend_data_json = json.dumps({'dates': trend_dates, 'top': trend_top, 'bot': trend_bot}, ensure_ascii=False)
    strength_data_json = json.dumps({'strong': strength_counts['強'], 'medium': strength_counts['中'], 'weak': strength_counts['弱']}, ensure_ascii=False)

    if trend_dates:
        trend_html = '<div class="chart-container"><canvas id="trendChart"></canvas></div>'
    else:
        trend_html = '<p style="color:var(--muted);text-align:center;padding:40px 0;">⏳ 等幾日先有數據（每日 06:00 自動更新）</p>'

    nq_high = nq_data.get('high', 0)
    nq_low = nq_data.get('low', 0)
    nq_current = nq_data.get('current', 0)
    nq_r1 = nq_data.get('r1', 0)
    nq_pivot = nq_data.get('pivot', 0)
    nq_s1 = nq_data.get('s1', 0)

    if nq_high > 0 and nq_low > 0:
        nq_pct = ((nq_current - nq_low) / (nq_high - nq_low)) * 100
        nq_html = f'''
        <div class="keylevel">
          <div class="keylevel-bar" id="nq-bar" data-pct="{nq_pct}"></div>
          <div class="keylevel-labels">
            <span>5日低 {nq_low:,.1f}</span>
            <span>現價 {nq_current:,.1f}</span>
            <span>5日高 {nq_high:,.1f}</span>
          </div>
        </div>
        <div style="margin-top:15px;font-size:13px;line-height:1.8;">
          <div>🔴 R1 第一壓力：<strong>{nq_r1:,.1f}</strong></div>
          <div>⚪ Pivot 中軸：<strong>{nq_pivot:,.1f}</strong></div>
          <div>🟢 S1 第一支撐：<strong>{nq_s1:,.1f}</strong></div>
        </div>'''
    else:
        nq_html = '<p style="color:var(--muted);">暫無數據</p>'

    # ===== 回測區 HTML（可排序）=====
    backtest_html = ""
    if backtest_data:
        rows_data = []
        for ticker, levels in backtest_data.items():
            for lv, dirs in levels.items():
                for direction in ['底', '頂']:
                    if direction in dirs and dirs[direction].get('T+5'):
                        s = dirs[direction]['T+5']
                        rows_data.append({
                            'ticker': ticker,
                            'level': lv,
                            'direction': direction,
                            'winRate': s['winRate'],
                            'count': s['count'],
                            'avgChange': s['avgChange'],
                        })

        if rows_data:
            body_rows = []
            for r in rows_data:
                win_rate = r['winRate']
                if win_rate >= 65:
                    win_class = 'color:#3fb950;font-weight:bold;'
                elif win_rate >= 55:
                    win_class = 'color:#d29922;font-weight:bold;'
                else:
                    win_class = 'color:#f85149;'

                dir_icon = '🟢 底' if r['direction'] == '底' else '🔴 頂'

                body_rows.append(f'''
                <tr data-ticker="{r['ticker']}" data-level="{r['level']}" data-direction="{r['direction']}" data-winrate="{win_rate}" data-count="{r['count']}" data-avgchange="{r['avgChange']}">
                  <td>{r['ticker']}</td>
                  <td>{r['level']}</td>
                  <td>{dir_icon}</td>
                  <td style="{win_class}">{win_rate}%</td>
                  <td>{r['count']}</td>
                  <td>{r['avgChange']:+.2f}%</td>
                </tr>''')

            backtest_html = f'''
            <div class="card">
              <h2 style="margin-top:0;">📊 回測結果（10 年）— T+5 成功率</h2>
              <p style="color:var(--muted);font-size:12px;margin-top:5px;">💡 撳欄位標題可以排序</p>
              <div class="scroll" style="max-height:500px;">
                <table class="table" id="backtest-table">
                  <thead>
                    <tr>
                      <th onclick="sortBacktest('ticker')" style="cursor:pointer;">標的 ↕</th>
                      <th onclick="sortBacktest('level')" style="cursor:pointer;">週期 ↕</th>
                      <th onclick="sortBacktest('direction')" style="cursor:pointer;">方向 ↕</th>
                      <th onclick="sortBacktest('winrate')" style="cursor:pointer;">勝率 ↕</th>
                      <th onclick="sortBacktest('count')" style="cursor:pointer;">樣本 ↕</th>
                      <th onclick="sortBacktest('avgchange')" style="cursor:pointer;">平均升跌 ↕</th>
                    </tr>
                  </thead>
                  <tbody>
                    {''.join(body_rows)}
                  </tbody>
                </table>
              </div>
            </div>'''

    html = f"""<!DOCTYPE html>
<html lang="zh-HK" data-theme="dark">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>⚡ 0DTE Radar Dashboard V20.2</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  * {{ box-sizing: border-box; }}
  :root {{
    --bg: #0d1117; --card: #161b22; --border: #30363d;
    --text: #c9d1d9; --muted: #8b949e; --accent: #58a6ff;
    --top-bg: rgba(248, 81, 73, 0.08); --top-hover: rgba(248, 81, 73, 0.15);
    --bot-bg: rgba(63, 185, 80, 0.08); --bot-hover: rgba(63, 185, 80, 0.15);
    --top-color: #f85149; --bot-color: #3fb950;
  }}
  [data-theme="light"] {{
    --bg: #f6f8fa; --card: #ffffff; --border: #d0d7de;
    --text: #1f2328; --muted: #656d76; --accent: #0969da;
    --top-bg: rgba(207, 34, 46, 0.08); --top-hover: rgba(207, 34, 46, 0.15);
    --bot-bg: rgba(26, 127, 55, 0.08); --bot-hover: rgba(26, 127, 55, 0.15);
    --top-color: #cf222e; --bot-color: #1a7f37;
  }}
  body {{
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: var(--bg); color: var(--text);
    margin: 0; padding: 20px; transition: all 0.3s;
  }}
  .container {{ max-width: 1500px; margin: 0 auto; }}
  h1 {{ color: var(--accent); border-bottom: 2px solid var(--border); padding-bottom: 10px; display: flex; justify-content: space-between; align-items: center; }}
  h2 {{ color: var(--accent); margin-top: 30px; border-left: 4px solid var(--accent); padding-left: 10px; }}
  .card {{
    background: var(--card); border: 1px solid var(--border); border-radius: 8px;
    padding: 15px; margin: 10px 0; transition: all 0.3s;
  }}
  .card:hover {{ transform: translateY(-2px); box-shadow: 0 4px 12px rgba(0,0,0,0.2); }}
  .stats {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(120px, 1fr)); gap: 15px; margin: 15px 0; }}
  .stat-box {{
    background: var(--card); border: 1px solid var(--border); border-radius: 8px;
    padding: 15px; text-align: center; transition: all 0.2s;
  }}
  .stat-box:hover {{ border-color: var(--accent); }}
  .stat-box .num {{ font-size: 28px; font-weight: bold; color: var(--accent); }}
  .stat-box .label {{ font-size: 12px; color: var(--muted); margin-top: 5px; }}
  .stat-box.top .num {{ color: var(--top-color); }}
  .stat-box.bot .num {{ color: var(--bot-color); }}
  .delta {{ font-size: 13px; font-weight: bold; }}
  .delta.up {{ color: var(--top-color); }}
  .delta.down {{ color: var(--bot-color); }}

  .grid-2 {{ display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }}
  .grid-3 {{ display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; }}
  @media (max-width: 768px) {{ .grid-2, .grid-3 {{ grid-template-columns: 1fr; }} }}

  .chart-container {{ position: relative; height: 250px; }}
  .donut-container {{ position: relative; height: 200px; }}

  table.table {{ width: 100%; border-collapse: collapse; font-size: 13px; margin-top: 10px; }}
  table.table th {{
    background: linear-gradient(180deg, var(--card) 0%, var(--bg) 100%);
    color: var(--accent); padding: 10px; text-align: left;
    border-bottom: 2px solid var(--border); position: sticky; top: 0; z-index: 10;
    white-space: nowrap;
  }}
  table.table td {{ padding: 8px 10px; border-bottom: 1px solid var(--border); white-space: nowrap; }}
  table.table tr {{ transition: background 0.2s; cursor: pointer; }}

  #backtest-table th:hover {{ background: var(--border); }}
  #backtest-table tr {{ cursor: default; }}

  tr.top-row {{ background: var(--top-bg); }}
  tr.top-row:hover {{ background: var(--top-hover); }}
  tr.bot-row {{ background: var(--bot-bg); }}
  tr.bot-row:hover {{ background: var(--bot-hover); }}

  .strength-bar {{
    position: relative; width: 60px; height: 18px; background: var(--bg);
    border-radius: 9px; overflow: hidden; display: inline-block;
  }}
  .strength-fill {{ position: absolute; left: 0; top: 0; bottom: 0; }}
  .strength-fill.strength-強 {{ background: #f85149; }}
  .strength-fill.strength-中 {{ background: #d29922; }}
  .strength-fill.strength-弱 {{ background: #6e7681; }}
  .strength-text {{
    position: relative; z-index: 1; font-size: 11px; font-weight: bold;
    color: white; line-height: 18px; padding-left: 6px;
  }}

  .resonance-badge {{
    display: inline-block; padding: 2px 8px; border-radius: 10px;
    font-size: 11px; font-weight: bold;
  }}
  .resonance-dual {{ background: #a371f7; color: white; }}
  .resonance-single {{ background: #30363d; color: var(--muted); }}

  .controls {{
    display: flex; gap: 10px; flex-wrap: wrap; margin: 15px 0;
    padding: 15px; background: var(--card); border: 1px solid var(--border); border-radius: 8px;
    align-items: center;
  }}
  .btn {{
    padding: 8px 14px; border: 1px solid var(--border); background: var(--bg);
    color: var(--text); border-radius: 6px; cursor: pointer;
    font-size: 13px; transition: all 0.2s;
  }}
  .btn:hover {{ background: var(--border); }}
  .btn.active {{ background: var(--accent); color: white; border-color: var(--accent); }}
  .search-input {{
    padding: 8px 14px; border: 1px solid var(--border); background: var(--bg);
    color: var(--text); border-radius: 6px; font-size: 13px; min-width: 200px;
  }}
  .search-input:focus {{ outline: none; border-color: var(--accent); }}
  .label-text {{ color: var(--muted); font-size: 13px; }}

  .bar-row {{ display: flex; align-items: center; gap: 10px; margin: 8px 0; }}
  .bar-label {{ width: 80px; font-size: 13px; font-weight: bold; }}
  .bar-track {{ flex: 1; height: 20px; background: var(--bg); border-radius: 10px; overflow: hidden; }}
  .bar-fill {{ height: 100%; background: linear-gradient(90deg, var(--accent) 0%, #1f6feb 100%); border-radius: 10px; }}
  .bar-count {{ width: 40px; text-align: right; font-size: 13px; color: var(--muted); }}

  .resonance-item {{ padding: 8px 0; font-size: 14px; border-bottom: 1px solid var(--border); }}
  .resonance-item:last-child {{ border-bottom: none; }}

  .keylevel {{ margin: 15px 0; }}
  .keylevel-bar {{
    position: relative; height: 30px;
    background: linear-gradient(90deg, var(--bot-color) 0%, var(--bg) 50%, var(--top-color) 100%);
    border-radius: 15px;
  }}
  .keylevel-marker {{
    position: absolute; top: -5px; width: 4px; height: 40px;
    background: white; border-radius: 2px; box-shadow: 0 0 8px rgba(255,255,255,0.8);
  }}
  .keylevel-labels {{ display: flex; justify-content: space-between; margin-top: 8px; font-size: 12px; color: var(--muted); }}

  .modal {{
    display: none; position: fixed; top: 0; left: 0; right: 0; bottom: 0;
    background: rgba(0,0,0,0.7); z-index: 1000;
    justify-content: center; align-items: center; padding: 20px;
  }}
  .modal.active {{ display: flex; }}
  .modal-content {{
    background: var(--card); border: 1px solid var(--border); border-radius: 12px;
    max-width: 500px; width: 100%; padding: 25px; position: relative;
    max-height: 80vh; overflow-y: auto;
  }}
  .modal-close {{
    position: absolute; top: 15px; right: 15px; cursor: pointer;
    background: var(--bg); border: 1px solid var(--border); color: var(--text);
    width: 30px; height: 30px; border-radius: 50%; font-size: 16px;
  }}
  .modal-row {{ display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid var(--border); }}
  .modal-row:last-child {{ border-bottom: none; }}
  .modal-label {{ color: var(--muted); }}
  .modal-value {{ font-weight: bold; }}

  .footer {{
    margin-top: 40px; text-align: center; color: var(--muted);
    font-size: 12px; border-top: 1px solid var(--border); padding-top: 20px;
  }}
  .scroll {{ overflow-x: auto; max-height: 700px; overflow-y: auto; }}

  @media (max-width: 768px) {{
    body {{ padding: 10px; }}
    h1 {{ font-size: 20px; }}
    h2 {{ font-size: 16px; }}
    .stat-box .num {{ font-size: 22px; }}
    .controls {{ flex-direction: column; align-items: stretch; }}
    .search-input {{ min-width: auto; width: 100%; }}
    table.table {{ font-size: 12px; }}
    table.table th, table.table td {{ padding: 6px 8px; }}
  }}
</style>
</head>
<body>
<div class="container">

<h1>
  <span>⚡ 0DTE Radar Dashboard V20.2</span>
  <button class="btn" onclick="toggleTheme()" id="theme-btn">🌙</button>
</h1>
<p style="color:var(--muted);">最後更新：{now_hkt} HKT</p>

<div class="stats">
  <div class="stat-box">
    <div class="num">{total_signals}</div>
    <div class="label">總訊號數</div>
  </div>
  <div class="stat-box">
    <div class="num">{today_count}</div>
    <div class="label">今日訊號</div>
  </div>
  <div class="stat-box top">
    <div class="num">{today_top}</div>
    <div class="label">🔴 頂背離</div>
  </div>
  <div class="stat-box bot">
    <div class="num">{today_bot}</div>
    <div class="label">🟢 底背離</div>
  </div>
  <div class="stat-box">
    <div class="num">{today_strong}</div>
    <div class="label">🔥 強訊號</div>
  </div>
</div>

<div class="card">
  <strong>📈 今日 vs 昨日：</strong>
  今日 <span style="color:var(--accent);font-weight:bold;">{today_count}</span>
  | 昨日 <span style="color:var(--muted);">{yesterday_count}</span>
  | 變化 <span class="delta {diff_class}">{diff_str}</span>
</div>

<div class="grid-2">
  <div class="card">
    <h2 style="margin-top:0;">📊 歷史趨勢（30 日）</h2>
    {trend_html}
  </div>
  <div class="card">
    <h2 style="margin-top:0;">📊 強度分佈（今日）</h2>
    <div class="donut-container"><canvas id="donutChart"></canvas></div>
  </div>
</div>

<div class="grid-3">
  <div class="card">
    <h2 style="margin-top:0;">📅 財經日曆</h2>
    <div style="font-size:13px;line-height:1.6;">{fmp_html}</div>
  </div>
  <div class="card">
    <h2 style="margin-top:0;">🛡️ NQ 5m EMA 帶</h2>
    <div style="font-size:13px;">{ema_html}</div>
  </div>
  <div class="card">
    <h2 style="margin-top:0;">📍 NQ 關鍵位</h2>
    {nq_html}
  </div>
</div>

<div class="grid-2">
  <div class="card">
    <h2 style="margin-top:0;">📈 Top 5 標的（30 日）</h2>
    {top_tickers_html if top_tickers_html else '<p style="color:var(--muted);">暫無數據</p>'}
  </div>
  <div class="card">
    <h2 style="margin-top:0;">⭐ 多週期共振</h2>
    {resonance_html}
  </div>
</div>

{backtest_html}

<h2>🔥 今日訊號</h2>

<div class="controls">
  <span class="label-text">篩選：</span>
  <button class="btn active" data-filter="all" onclick="filterRows('all', this)">全部</button>
  <button class="btn" data-filter="top" onclick="filterRows('top', this)">🔴 頂</button>
  <button class="btn" data-filter="bot" onclick="filterRows('bot', this)">🟢 底</button>
  <button class="btn" data-filter="strong" onclick="filterRows('strong', this)">🔥 強</button>
  <button class="btn" data-filter="dual" onclick="filterRows('dual', this)">⭐⭐ 雙指標</button>

  <span class="label-text" style="margin-left:20px;">排序：</span>
  <button class="btn" onclick="sortBy('strength', this)">按強度</button>
  <button class="btn" onclick="sortBy('ticker', this)">按標的</button>

  <input type="text" class="search-input" placeholder="🔎 搜尋（可逗號分隔）..." oninput="searchRows(this.value)">

  <button class="btn" onclick="exportCSV()" style="margin-left:auto;">📥 匯出 CSV</button>
</div>

<div class="card scroll">
  <table class="table" id="today-table">
    <thead><tr>{header_html}</tr></thead>
    <tbody>{df_to_rows(today_df)}</tbody>
  </table>
</div>

<div class="footer">
  ⚡ Radar V20.2 | Powered by GitHub Actions + GitHub Pages
</div>

</div>

<div class="modal" id="modal" onclick="if(event.target===this) closeModal()">
  <div class="modal-content">
    <button class="modal-close" onclick="closeModal()">✕</button>
    <h2 id="modal-title" style="margin-top:0;"></h2>
    <div id="modal-body"></div>
  </div>
</div>

<script>
function toggleTheme() {{
  const html = document.documentElement;
  const current = html.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  html.setAttribute('data-theme', next);
  document.getElementById('theme-btn').textContent = next === 'dark' ? '🌙' : '☀️';
  localStorage.setItem('theme', next);
}}
(function() {{
  const saved = localStorage.getItem('theme');
  if (saved) {{
    document.documentElement.setAttribute('data-theme', saved);
    document.getElementById('theme-btn').textContent = saved === 'dark' ? '🌙' : '☀️';
  }}
}})();

let currentFilter = 'all';

function filterRows(type, btn) {{
  document.querySelectorAll('.controls .btn[data-filter]').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
  currentFilter = type;
  applyFilters();
}}

function searchRows(query) {{
  applyFilters(query);
}}

function applyFilters(query = '') {{
  const rows = document.querySelectorAll('#today-table tbody tr');
  const queries = query.toLowerCase().split(',').map(q => q.trim()).filter(q => q);

  rows.forEach(row => {{
    if (!row.dataset.direction) return;
    const direction = row.dataset.direction;
    const strength = row.dataset.strength;
    const resonance = row.dataset.resonance;
    const ticker = (row.dataset.ticker || '').toLowerCase();

    let show = true;
    if (currentFilter === 'top' && direction !== '頂') show = false;
    if (currentFilter === 'bot' && direction !== '底') show = false;
    if (currentFilter === 'strong' && strength !== '強') show = false;
    if (currentFilter === 'dual' && resonance !== '雙指標') show = false;

    if (queries.length > 0) {{
      let matched = false;
      for (const q of queries) {{
        if (ticker.includes(q)) {{ matched = true; break; }}
      }}
      if (!matched) show = false;
    }}

    row.style.display = show ? '' : 'none';
  }});
}}

function sortBy(key, btn) {{
  const tbody = document.querySelector('#today-table tbody');
  const rows = Array.from(tbody.querySelectorAll('tr[data-direction]'));
  const strengthOrder = {{'強': 1, '中': 2, '弱': 3}};

  rows.sort((a, b) => {{
    if (key === 'strength') {{
      return (strengthOrder[a.dataset.strength] || 9) - (strengthOrder[b.dataset.strength] || 9);
    }} else if (key === 'ticker') {{
      return (a.dataset.ticker || '').localeCompare(b.dataset.ticker || '');
    }}
    return 0;
  }});

  rows.forEach(r => tbody.appendChild(r));
  document.querySelectorAll('.controls .btn:not([data-filter])').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
}}

// ===== 回測區排序 =====
let backtestSortColumn = null;
let backtestSortOrder = 'desc';

function sortBacktest(column) {{
  const tbody = document.querySelector('#backtest-table tbody');
  if (!tbody) return;

  const rows = Array.from(tbody.querySelectorAll('tr'));

  if (backtestSortColumn === column) {{
    backtestSortOrder = backtestSortOrder === 'asc' ? 'desc' : 'asc';
  }} else {{
    backtestSortColumn = column;
    backtestSortOrder = 'desc';
  }}

  rows.sort((a, b) => {{
    let valA, valB;

    if (column === 'ticker') {{
      valA = a.dataset.ticker || '';
      valB = b.dataset.ticker || '';
      return backtestSortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }} else if (column === 'level') {{
      const order = {{'M': 1, 'W': 2, 'D': 3, '4H': 4}};
      valA = order[a.dataset.level] || 99;
      valB = order[b.dataset.level] || 99;
    }} else if (column === 'direction') {{
      valA = a.dataset.direction || '';
      valB = b.dataset.direction || '';
      return backtestSortOrder === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
    }} else if (column === 'winrate') {{
      valA = parseFloat(a.dataset.winrate) || 0;
      valB = parseFloat(b.dataset.winrate) || 0;
    }} else if (column === 'count') {{
      valA = parseInt(a.dataset.count) || 0;
      valB = parseInt(b.dataset.count) || 0;
    }} else if (column === 'avgchange') {{
      valA = parseFloat(a.dataset.avgchange) || 0;
      valB = parseFloat(b.dataset.avgchange) || 0;
    }}

    return backtestSortOrder === 'asc' ? valA - valB : valB - valA;
  }});

  rows.forEach(r => tbody.appendChild(r));
}}

function showDetail(row) {{
  try {{
    const data = JSON.parse(row.dataset.json.replace(/&#39;/g, "'"));
    document.getElementById('modal-title').textContent = `${{data.name}} (${{data.ticker}})`;
    const body = document.getElementById('modal-body');

    const dirIcon = data.direction === '頂' ? '🔴 頂背離' : '🟢 底背離';
    const rows = [
      ['日期', data.date], ['週期', data.level], ['方向', dirIcon],
      ['型態', data.tag], ['長/短', data.lookback],
      ['前高/低', data.prev_price], ['現價', data.current_price],
      ['價變化', data.price_change + '%'],
      ['DIF 變化', data.dif_change ? data.dif_change + '%' : '—'],
      ['J 變化', data.j_change ? data.j_change + '%' : '—'],
      ['DIF 有冇', data.has_dif], ['J 有冇', data.has_j],
      ['強度', data.strength], ['共振', data.resonance],
      ['歷史勝率', data.win_rate || '—'],
    ];

    body.innerHTML = rows.map(([k, v]) => 
      `<div class="modal-row"><span class="modal-label">${{k}}</span><span class="modal-value">${{v}}</span></div>`
    ).join('');

    document.getElementById('modal').classList.add('active');
  }} catch(e) {{ console.error(e); }}
}}

function closeModal() {{
  document.getElementById('modal').classList.remove('active');
}}

function exportCSV() {{
  const rows = document.querySelectorAll('#today-table tbody tr[data-direction]');
  const visibleRows = Array.from(rows).filter(r => r.style.display !== 'none');

  const headers = Array.from(document.querySelectorAll('#today-table thead th')).map(th => th.innerText.trim());
  let csv = headers.join(',') + '\\n';
  visibleRows.forEach(r => {{
    const cells = Array.from(r.querySelectorAll('td')).map(td => {{
      let text = td.innerText.trim();
      if (text.includes(',')) text = `"${{text}}"`;
      return text;
    }});
    csv += cells.join(',') + '\\n';
  }});

  const blob = new Blob(['\\ufeff' + csv], {{ type: 'text/csv;charset=utf-8;' }});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `radar_${{new Date().toISOString().slice(0,10)}}.csv`;
  a.click();
}}

const trendData = {trend_data_json};
const strengthData = {strength_data_json};

const isDark = () => document.documentElement.getAttribute('data-theme') === 'dark';
const chartTextColor = () => isDark() ? '#c9d1d9' : '#1f2328';
const chartGridColor = () => isDark() ? '#30363d' : '#d0d7de';

const trendCtx = document.getElementById('trendChart');
if (trendCtx && trendData.dates.length > 0) {{
  new Chart(trendCtx, {{
    type: 'line',
    data: {{
      labels: trendData.dates.map(d => d.slice(5)),
      datasets: [
        {{ label: '頂背離', data: trendData.top, borderColor: '#f85149', backgroundColor: 'rgba(248, 81, 73, 0.1)', tension: 0.3, fill: true }},
        {{ label: '底背離', data: trendData.bot, borderColor: '#3fb950', backgroundColor: 'rgba(63, 185, 80, 0.1)', tension: 0.3, fill: true }}
      ]
    }},
    options: {{
      responsive: true, maintainAspectRatio: false,
      plugins: {{ legend: {{ labels: {{ color: chartTextColor() }} }} }},
      scales: {{
        x: {{ ticks: {{ color: chartTextColor() }}, grid: {{ color: chartGridColor() }} }},
        y: {{ ticks: {{ color: chartTextColor() }}, grid: {{ color: chartGridColor() }}, beginAtZero: true }}
      }}
    }}
  }});
}}

const donutCtx = document.getElementById('donutChart');
if (donutCtx) {{
  new Chart(donutCtx, {{
    type: 'doughnut',
    data: {{
      labels: ['強', '中', '弱'],
      datasets: [{{
        data: [strengthData.strong, strengthData.medium, strengthData.weak],
        backgroundColor: ['#f85149', '#d29922', '#6e7681'],
        borderWidth: 2, borderColor: chartGridColor(),
      }}]
    }},
    options: {{
      responsive: true, maintainAspectRatio: false,
      plugins: {{ legend: {{ position: 'bottom', labels: {{ color: chartTextColor() }} }} }}
    }}
  }});
}}

const nqBar = document.getElementById('nq-bar');
if (nqBar) {{
  const pct = parseFloat(nqBar.dataset.pct || '50');
  const marker = document.createElement('div');
  marker.className = 'keylevel-marker';
  marker.style.left = Math.max(0, Math.min(100, pct)) + '%';
  nqBar.appendChild(marker);
}}
</script>

</body>
</html>"""

    with open('index.html', 'w', encoding='utf-8') as f:
        f.write(html)

    print(f"✅ 生成 index.html ({len(html)} 字元)")

if __name__ == '__main__':
    build_html()
